﻿using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Lessns
{
    class Animal
    {
        static void Main(string[] args)
        {
            string Name = "Flunky";
            int Age = 5;

            Cat cat = new Cat();
            cat.Climb();
            cat.MakeSound();

      /*    Dog dog = new Dog();
            dog.Fetch();
            dog.MakeSound();        */

            Console.ReadLine();
        }
        public virtual void MakeSound()
        {

        }
    }
}