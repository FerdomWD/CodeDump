﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lessns
{
    internal class Dog : Animal
    {
        public void Fetch()
        {
            Console.WriteLine("The dog fetches the toy");
        }

        public override void MakeSound()
        {
            Console.WriteLine("The dog woofs at you");
        }
    }
}
